---
name: savyre-chat
description: >-
  Savyre Chat continue/next adapter for Codex. Use when the developer says next,
  continue, lock, approve design, answer an open question, or asks how to advance
  a Savyre stage. Call MCP savyre_next / savyre_answer when available.
---

# Savyre Chat (Codex)

## Role

You are **not** the Savyre lock. Codex IDE does not run Cursor `/savyre-next`. Advance only through the **Savyre host**.

## Preferred order when the developer wants to continue

1. **Call MCP tool `savyre_next`** if the `savyre` MCP server is connected (project `.mcp.json` after `install-project.mjs`).
2. Otherwise tell them to run Command Palette **Savyre: Next** (Savyre extension ≥ 0.3.89).
3. Or Savyre panel → Next.
4. CLI fallback (from the project folder):  
   `node <path-to>/savyre-codex-plugin/scripts/savyre-cli.mjs next`

After any of these, speak the returned **`userMessage` exactly** as the developer-facing next line. Do not invent lock/ACCEPTED text. JSON `message` is agent-only — follow it silently.

## Answers (open question / design checkpoint)

1. Call MCP **`savyre_answer`** with `{ "answer": "1" }` (or `2`/`3`/free text). Include `questionId` when you know `OQ-001`.
2. Or Command Palette **Savyre: Answer**.
3. Then continue with `savyre_next` only when the host `userMessage` says so.

## Other tools

- `savyre_start` — bind to panel stage  
- `savyre_status` — checkpoint status  
- `savyre_stop` — turn lock off (does not accept the stage)

## UI design (S04)

In Codex prefer portable `designBrief` / `designSpecification` + `preview.html`. Do not write product UI until designCheckpoint is approved.

## Never

- Invent Cursor `/savyre-next` as if it ran in this tab  
- Claim ACCEPTED / unlock from Chat alone  
- Invent canned MVP / minimum-functionality OQs when scope is already UI-only
