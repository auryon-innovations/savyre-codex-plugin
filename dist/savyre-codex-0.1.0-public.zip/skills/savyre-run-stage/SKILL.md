---
name: savyre-run-stage
description: >-
  Bootstrap or resume the active Savyre stage in Codex. Use when a Savyre stage
  is enforced and the user wants the current stage run, resumed, or clarified.
  Pick the matching role skill; do not invent Savyre methodology.
---

# Run Stage (Codex)

## Role

Route to the correct Savyre stage **role skill** for the active stage. You do not approve, unlock, or accept stages.

## Procedure

1. Read the Savyre panel / `.savyre` session context if present (current stage id).
2. Prefer candidate-bundle skills when installed (`savyre-stage-task-definition`, `savyre-stage-build-review`, etc.).
3. For continue/next after drafting, switch to `$savyre-chat` so progress goes through the Savyre host.
4. Never invent stage textbooks — methodology lives in the Savyre extension prompts and org candidate bundle.

## Handoff

Name the active stage and which skill you are following. Ask the developer to run Savyre Next via panel/palette/MCP when a host checkpoint is required.
